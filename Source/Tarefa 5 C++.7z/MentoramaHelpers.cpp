// Fill out your copyright notice in the Description page of Project Settings.


#include "MentoramaHelpers.h"

int UMentoramaHelpers::Factorial(int Number)
{
	unsigned long int factorial = 1;

	if (Number == 0 || Number == 1)
		return 1;
	else
		while (Number > 1) {
			factorial *= Number;
			Number--;
		}
	return factorial;
}

int UMentoramaHelpers::FindFirstDivisibleNumber(int Number)
{
	int Result = 2;

	//Trava a UE
	/*do {
		if (Number % Result == 0)
			return Result;
		
		Result += 2;
	} while (true);*/


	do {
		if (Result % 2 == 0) {
			Result++;
			continue;
		}

		if (Number % Result == 0)
			break;
		else
			Result++;
	} while (Result < Number);

	return Result;
}

bool UMentoramaHelpers::IsPrime(int Number)
{
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Helpers")
	bool Ans = true;

	if (Number <= 0)
		Ans = false;
	else if (Number == 1 || Number == 2)
		Ans = true;
	else
		for (int Divisor = 2; Divisor <= Number / 2; Divisor++)
			if (Number % Divisor == 0)
				Ans = false;
	return Ans;
}

