// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "MentoramaHelpers.generated.h"

/**
 * 
 */
UCLASS()
class MENTORAMA_API UMentoramaHelpers : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "Helpers")
	static int MySum(int a, int b, int c) { return a + b + c; };

	UFUNCTION(BlueprintPure, Category = "Helpers")
	static int Factorial(int Number);

	UFUNCTION(BlueprintPure, Category = "Helpers")
	static int FindFirstDivisibleNumber(int Number);

	UFUNCTION(BlueprintCallable, Category = "Helpers")
	static bool IsPrime(int Number);
};
