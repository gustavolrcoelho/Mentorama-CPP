// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy.h"
#include "Kismet/KismetSystemLibrary.h"

// Sets default values
AEnemy::AEnemy()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	Direction.Set(0, 1, 0);
	TimeLapsed = 0;
	TimeToTurn = 4;
	Speed = 1.0f;
	Health = 100;
}

// Called when the game starts or when spawned
void AEnemy::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	UKismetSystemLibrary::PrintString(this, ToStr((OddEven(TimeLapsed))));
	MentoramaMoveEnemy(DeltaTime);
}

// Called to bind functionality to input
void AEnemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AEnemy::MentoramaMoveEnemy(float DeltaTime){
	TimeLapsed += DeltaTime;

	if (TimeLapsed > TimeToTurn) {
		Direction *= -1;
		TimeLapsed = 0;
	}

	AddMovementInput(Direction, Speed, false);
}

void AEnemy::MentoramaTakeDamage(float Damage){
	Health -= Damage;

	if (Health <= 0.0f)
		Destroy();
}

// Fiz aqui para mandar um arquivo s�
bool AEnemy::OddEven(int Number){
	if (Number % 2 == 0)
		return true;
	else
		return false;
}

// Converts boolean to string, in order to be able to be printed by UKismetSystemLibrary::PrintString
FString AEnemy::ToStr(bool Bool)
{
	if (Bool)
		return "True";
	else
		return "False";
}

