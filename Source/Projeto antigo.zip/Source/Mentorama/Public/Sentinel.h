// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Enemy.h"
#include "PlayerCharacter.h"
#include "Sentinel.generated.h"


UCLASS()
class MENTORAMA_API ASentinel : public AEnemy
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ASentinel();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	////Player position
	//FVector PlayerPosition;
	//
	////Default spawn location of the sentinel
	//FVector SpawnLocation;

	////Current position of the sentinel
	//FVector OwnPosition;

public:
	////The current state of the enemy, which can be modified through interactions with it
	//ECurrentState CurrentState;
	//
	//UPROPERTY(BlueprintReadWrite, EditAnywhere)
	////Max range at which the Sentinel can spot the PlayerCharacter
	//float MaxSightingRange;

	//UPROPERTY(BlueprintReadWrite, EditAnywhere)
	////Current range at which the Sentinel can spot the PlayerCharacter
	//float CurrentSightingRange;

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	//Moves Sentinel enemy
	//void Patrol(float DeltaTime);
};