// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ATM.generated.h"

UCLASS()
class MENTORAMA_API AATM : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AATM();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void ProcessWithdraw(int amount);

	int Control;
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(EditAnywhere)
	int Bills[7];

	UPROPERTY(EditAnywhere)
	int MoneyReserve;

	UPROPERTY(EditAnywhere)
	int Withdraw;

};
