#pragma once
class Calculator
{
protected:
	float A, B;

public:
	Calculator() {};
	Calculator(float OperandA, float OperandB) { A = OperandA; B = OperandB; };
	~Calculator() {};

	static float Sum			(float A, float B) { return A += B; }
		   float Sum			(/*  NO ARGS   */) { return A += B; }

	static float Subtraction	(float A, float B) { return A -= B; }
		   float Subtraction	(/*  NO ARGS   */) { return A -= B; }

	static float Multiplication	(float A, float B) { return A *= B; }
		   float Multiplication	(/*  NO ARGS   */) { return A *= B; }
	
	static float Division		(float A, float B) { return A /= B; }
		   float Division		(/*  NO ARGS   */) { return A /= B; }
};

