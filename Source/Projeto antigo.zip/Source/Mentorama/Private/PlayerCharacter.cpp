// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerCharacter.h"
#include "Kismet/GamePlayStatics.h"

// Sets default values
APlayerCharacter::APlayerCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	CurrentHealth = MaxHealth;
}

void APlayerCharacter::BeginPlay()
{
	Super::BeginPlay();
	UGameplayStatics::GetAllActorsOfClass(this, ACharacter::StaticClass(), Characters);
}

void APlayerCharacter::SetupPlayerInputComponent(UInputComponent* inputComponent)
{
	Super::SetupPlayerInputComponent(inputComponent);
	inputComponent->BindAction("Fire", EInputEvent::IE_Pressed, this, &APlayerCharacter::MakeAllCharactersJump);
}

void APlayerCharacter::MakeAllCharactersJump()
{
	/*for (AActor* Characters : Characters) {
		Cast<ACharacter>(Characters)->Jump();
	}*/
}

void APlayerCharacter::HandleDamage(int Damage)
{
	CurrentHealth -= Damage;
	OnHealthChanged.Broadcast(CurrentHealth);
}

void APlayerCharacter::Attack()
{
	HandleDamage(10);
}

