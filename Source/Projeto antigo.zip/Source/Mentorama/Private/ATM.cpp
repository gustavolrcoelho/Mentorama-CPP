// Fill out your copyright notice in the Description page of Project Settings.


#include "ATM.h"

// Sets default values
AATM::AATM()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	MoneyReserve = 5000;

	// Sets all positions to zero
	for (short i = 0; i < 7; i++)
		Bills[i] = 0;
}

// Called when the game starts or when spawned
void AATM::BeginPlay()
{
	Super::BeginPlay();
	ProcessWithdraw(Withdraw); //Initial bill sorting
}

// Called every frame
void AATM::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	// Checks whether the value of Withdraw has changed, then clears the tally and starts over
	if (Withdraw != Control) {
		for (short i = 0; i < 7; i++)
			Bills[i] = 0;

		ProcessWithdraw(Withdraw);
	}
}

void AATM::ProcessWithdraw(int amount) {
	int value = amount;

	if (value == 0) {
		MoneyReserve -= Withdraw;
		UE_LOG(LogTemp, Display, TEXT("Bills: %d x100, %d x50, %d x20, %d x10, %d x5, %d x2, %d x1."), Bills[6], Bills[5], Bills[4], Bills[3], Bills[2], Bills[1], Bills[0]);
		Control = Withdraw; // If the value of value is zero, this means the sorting ended and the Control is set
		return;
	}
	else if (value > MoneyReserve) {
		UE_LOG(LogTemp, Display, TEXT("Amount over the maximum available. Please choose again."));
		Control = Withdraw; // If the Control is different than Withdraw, this means that the user wants to start over
		return;
	}
	// If value is greater than or equal 1 when divided, substract the value, adds 1 to the count of that bill and repeat
	else {
		if ((value / 100) >= 1) {
			Bills[6] += 1;
			value -= 100;
		}
		else if ((value / 50) >= 1) {
			Bills[5] += 1;
			value -= 50;
		}
		else if ((value / 20) >= 1) {
			Bills[4] += 1;
			value -= 20;
		}
		else if ((value / 10) >= 1) {
			Bills[3] += 1;
			value -= 10;
		}
		else if ((value / 5) >= 1) {
			Bills[2] += 1;
			value -= 5;
		}
		else if ((value / 2) >= 1) {
			Bills[1] += 1;
			value -= 2;
		}
		else if ((value / 1) == 1) {
			Bills[0] += 1;
			value -= 1;
		}

		Control = Withdraw;
	}
	ProcessWithdraw(value); // Recursion till value reaches zero, then prints the final tally
}

