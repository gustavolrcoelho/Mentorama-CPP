// Fill out your copyright notice in the Description page of Project Settings.


#include "MyPawnCPP.h"
#include "Kismet/KismetSystemLibrary.h"
#include "MentoramaHelpers.h"

// Sets default values
AMyPawnCPP::AMyPawnCPP()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AMyPawnCPP::BeginPlay()
{
	Super::BeginPlay();

	TArray<FString> Names{ "Isabel", "Helena", "Cristina", "Leopoldina", "Carlota", "Amelia", "Hebe" };

	//Names.Add(TEXT("Isabel"));				// Adds an entry
	//Names.Add(TEXT("Am�lia"));				// Adds an entry
	//Names.Add(TEXT("Carlota"));				// Adds an entry
	//Names.Insert(TEXT("Leopoldina"), 0);	// Inserts at the specificed position
	//Names.AddUnique(TEXT("Teresa"));		// Add only if unique
	//Names.Remove(TEXT("Carlota"));			// Removes an entry
	//Names.RemoveAt(2); 						// Removes at position
	
	UMentoramaHelpers::PrintStringArray(Names);
	RemoveAllWordsThatStartWith(Names, 'C');
	UMentoramaHelpers::PrintStringArray(Names);
}

// Called every frame
void AMyPawnCPP::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	//int count = 0;

	//while (count <= 5) {
	//	UE_LOG(LogTemp, Display, TEXT("Hello world in WHILE"));
	//	count++;
	//}

	//for(int i = 0; i < 5; i++)
	//	UE_LOG(LogTemp, Display, TEXT("Hello world in FOR"));

}


// Called to bind functionality to input
void AMyPawnCPP::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AMyPawnCPP::RemoveAllWordsThatStartWith(TArray<FString>& Names, TCHAR Letter)
{
	for (int i = 0; i < Names.Num(); i++)
		if (Names[i][0] == Letter)
		//if (Names[i].StartsWith(Letter))
			Names.RemoveAt(i);

}

