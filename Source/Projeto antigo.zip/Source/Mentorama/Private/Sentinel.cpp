// Fill out your copyright notice in the Description page of Project Settings.


#include "Sentinel.h"
#include "Kismet/GamePlayStatics.h"

// Sets default values
ASentinel::ASentinel()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ASentinel::BeginPlay()
{
	Super::BeginPlay();

	//CurrentSightingRange = MaxSightingRange;
	//CurrentMovementSpeed = MaxMovementSpeed;
	//CurrentHealth = MaxHealth;
	//CurrentState = ECurrentState::Patrol;

}

// Called every frame
void ASentinel::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//PlayerPosition = GetWorld()->GetFirstPlayerController()->GetPawn()->GetActorLocation();
	//OwnPosition = this->GetActorLocation();

}

// Called to bind functionality to input
void ASentinel::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

//void ASentinel::Patrol(float DeltaTime)
//{
//	TimeLapsed += DeltaTime;
//
//	switch (CurrentState) {
//		//If the enemy is dead, despawns entity to free resources.
//		case ECurrentState::Dead:
//			Destroy();
//			break;
//
//		//Checks if its current HP is full and if not, starts recovering
//		case ECurrentState::Recover:
//			if (CurrentHealth == MaxHealth) {
//				CurrentState = ECurrentState::AtFullHealth;
//			}
//			else {
//				CurrentHealth += 5 * DeltaTime;
//			}
//
//			break;
//
//		//If at full HP, starts patrolling
//		case ECurrentState::AtFullHealth:
//			CurrentState = ECurrentState::Patrol;
//			break;
//
//		//If patrolling and HP is not full, stops. If full, keep walking
//		case ECurrentState::Patrol:
//			
//			if (CurrentHealth <= 0x00) {
//			}
//			else if (CurrentHealth < MaxHealth) {
//				CurrentState = ECurrentState::Recover;
//				CurrentMovementSpeed = 0;
//			}
//			else if (PlayerPosition.X <= OwnPosition.X + CurrentSightingRange
//					|| PlayerPosition.Y <= OwnPosition.Y + CurrentSightingRange
//					  || PlayerPosition.Z <= OwnPosition.Z + CurrentSightingRange) {
//
//				CurrentState = ECurrentState::Attack;
//			}
//			else {
//				//CurrentState = ECurrentState::Patrol;
//				if (TimeLapsed > TimeToTurn) {
//					CurrentDirection *= -1;
//					TimeLapsed = 0;
//				}
//				
//				AddMovementInput(CurrentDirection, CurrentMovementSpeed, false);
//			}
//			break;
//
//		case ECurrentState::Attack:
//			//If Player character is out the current sighting range, the sentinel will move torwards it
//			if (PlayerPosition.X > OwnPosition.X + CurrentSightingRange
//				|| PlayerPosition.Y > OwnPosition.Y + CurrentSightingRange
//				  || PlayerPosition.Z > OwnPosition.Z + CurrentSightingRange) {
//
//				CurrentState = ECurrentState::Patrol;
//				CurrentMovementSpeed = MaxMovementSpeed;
//				AddMovementInput(SpawnLocation, CurrentMovementSpeed, false);
//			}
//			else if (PlayerPosition.X > OwnPosition.X - 3
//					|| PlayerPosition.Y > OwnPosition.Y - 3
//					  || PlayerPosition.Z > OwnPosition.Z - 3) {
//				AddMovementInput(PlayerPosition, CurrentMovementSpeed, false);
//			}
//			else {
//				CurrentMovementSpeed /= 3;
//				AddMovementInput(PlayerPosition, CurrentMovementSpeed, false);
//			}
//			break;
//	}
//
//}

