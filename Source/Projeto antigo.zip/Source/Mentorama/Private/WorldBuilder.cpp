// Fill out your copyright notice in the Description page of Project Settings.


#include "WorldBuilder.h"

// Sets default values
AWorldBuilder::AWorldBuilder()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	TileMapSize.X = 20;
	TileMapSize.Y = 20;
	TileMapSize.Z = 5;
	TileSize.Set(100, 100, 100);
}

// Called when the game starts or when spawned
void AWorldBuilder::BeginPlay()
{
	Super::BeginPlay();
	GenerateWorld();
	
}

void AWorldBuilder::GenerateWorld()
{
	FVector Position(0,0,0);

	for (int x = 0; x < TileMapSize.X; x++) {
		Position.Y = 0;
	
		for (int y = 0; y < TileMapSize.Y; y++) {
			Position.Z = 0;
			
			int Height = FMath::RandRange(1, TileMapSize.Z);

			// Tests if X or Y is either the Start or End of the Map, then builds a wall #MakeUnrealGreatAgain
			if (Position.X == 0.0f || Position.X == static_cast<float>(TileMapSize.X-1) * TileSize.X)
				for (int z = 0; z < TileMapSize.Z; z++) {
					GetWorld()->SpawnActor<AActor>(Tile.Get(), Position, FRotator::ZeroRotator);
					Position.Z += TileSize.Z;
				}
			else if (Position.Y == 0.0f || Position.Y == static_cast<float>(TileMapSize.Y - 1) *TileSize.X)
				for (int z = 0; z < TileMapSize.Z; z++) {
					GetWorld()->SpawnActor<AActor>(Tile.Get(), Position, FRotator::ZeroRotator);
					Position.Z += TileSize.Z;
				}
			else
				for (int z = 0; z < Height; z++) {
					GetWorld()->SpawnActor<AActor>(Tile.Get(), Position, FRotator::ZeroRotator);
					Position.Z += TileSize.Z;
				}

			Position.Y += TileSize.Y;
		}

		Position.X += TileSize.X;
	}
}

