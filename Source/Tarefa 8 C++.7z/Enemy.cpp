// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy.h"
#include "MentoramaHelpers.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/KismetStringLibrary.h"
#include "Calculator.h"
//#include "SentinelComponent.h"

// Sets default values
AEnemy::AEnemy()
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	TimeLapsed = 0;
	TimeToTurn = 4;
	CurrentDirection.Set(0, 1, 0);
	MaxSightingRange = 500; //Can be modified by items
	MaxMovementSpeed = 1.0f; //Can be modified by items
	MaxHealth = 100; //Can be modified by items 
	/*USentinelComponent*/SentinelComponent = CreateDefaultSubobject<USentinelComponent>(TEXT("SentinelComponent"));


	//for(int i = 0; i < 50; i++)
	//	Vec[i] = 0;
} 

// Called when the game starts or when spawned
void AEnemy::BeginPlay()
{
	Super::BeginPlay();
	
	SpawnLocation = this->GetActorLocation();
	CurrentSightingRange = MaxSightingRange;
	CurrentMovementSpeed = MaxMovementSpeed;
	CurrentHealth = MaxHealth;
	CurrentState = ECurrentState::Patrol;

}

// Called every frame
void AEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	PlayerPosition = GetWorld()->GetFirstPlayerController()->GetPawn()->GetActorLocation();
	OwnPosition = this->GetActorLocation();

	/*FString Word1 = "Parangaricotirimirruaro";
	//FString Word1 = "Pipoco";
	//FString Word2 = "abcddcba";
	//FString Word3 = "ovo";

	//UKismetSystemLibrary::PrintString(this, TEXT("&d"), UMentoramaHelpers::SumAll(Vec));
	//UKismetSystemLibrary::PrintString(this, UKismetStringLibrary::Conv_BoolToString((UMentoramaHelpers::IsPrime(10))));
	//UKismetSystemLibrary::PrintString(this, UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsOdd(TimeLapsed)));
	//UKismetSystemLibrary::PrintString(this, Word1 + TEXT(" palindrome result is ") + UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsPalindrome(Word1)));
	//UKismetSystemLibrary::PrintString(this, Word2 + TEXT(" palindrome result is ") + UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsPalindrome(Word2)));
	//UKismetSystemLibrary::PrintString(this, Word3 + TEXT(" palindrome result is ") + UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsPalindrome(Word3)));

	//UKismetSystemLibrary::PrintString(this, TEXT("Before shuffling:  ") + Word1);
	//UMentoramaHelpers::ShuffleString(Word1);
	//UKismetSystemLibrary::PrintString(this, TEXT("After shuffling:  ") + Word1);
	*/
	//Calculator* calc = new Calculator();
	//Calculator* Calc = new Calculator(CurrentMovementSpeed, CurrentHealth);

	//calc->Sum(1.0, 3.5);
	//Calculator::Division(CurrentMovementSpeed, CurrentHealth);
	MaxHealth;


	Patrol(DeltaTime);
}

// Called to bind functionality to input
void AEnemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AEnemy::Pursue(int Index, float OwnAxisCoordinate, float PlayerAxisCoordinate)
{
	switch(Index)
	{
		case 1:
			CurrentDirection.Set(1, 0, 0);
			break;
		case 2:
			CurrentDirection.Set(0, 1, 0);
			break;
		case 3:
			CurrentDirection.Set(0, 0, 1);
			break;

		break;
	}
	
	if (PlayerAxisCoordinate >= .0f)
	{
		if (OwnAxisCoordinate < (PlayerAxisCoordinate - CurrentSightingRange / 3))
		{
			AddMovementInput(CurrentDirection, CurrentMovementSpeed, false);
		}
		else if(OwnAxisCoordinate > (PlayerAxisCoordinate + CurrentSightingRange / 3))
		{
			AddMovementInput(CurrentDirection * -1, CurrentMovementSpeed, false);
		}
	}
	else if (PlayerAxisCoordinate < .0f)
	{
		if (OwnAxisCoordinate < (PlayerAxisCoordinate - CurrentSightingRange / 3))
		{
			AddMovementInput(CurrentDirection, CurrentMovementSpeed, false);
		}
		else if (OwnAxisCoordinate > (PlayerAxisCoordinate + CurrentSightingRange / 3))
		{
			AddMovementInput(CurrentDirection * -1, CurrentMovementSpeed, false);
		}
	}
}

void AEnemy::Patrol(float DeltaTime)
{
	TimeLapsed += DeltaTime;

	switch (CurrentState)
	{
		//If the enemy is dead, despawns entity to free resources.
		case ECurrentState::Dead:
			Destroy();
			break;

		//Checks if its current HP is full and if not, starts recovering
		case ECurrentState::Recover:
			if (CurrentHealth == MaxHealth)
			{
				CurrentState = ECurrentState::AtFullHealth;
				CurrentMovementSpeed = MaxMovementSpeed;
			}
			else
			{
				CurrentHealth += 250 * DeltaTime;
			}
			break;

		//If at full HP, starts patrolling
		case ECurrentState::AtFullHealth:
			CurrentState = ECurrentState::Patrol;
			break;

		//If patrolling and HP is not full, stops. If full, keep walking
		case ECurrentState::Patrol:

			if (CurrentHealth <= .0f)
			{
				CurrentState = ECurrentState::Dead;
			}
			else if (CurrentHealth < MaxHealth)
			{
				CurrentState = ECurrentState::Recover;
				CurrentMovementSpeed = 0;
			}
			else if(OwnPosition.Distance(OwnPosition, PlayerPosition) <= CurrentSightingRange)
			{
				CurrentState = ECurrentState::Attack;
			}
			else
			{
				CurrentState = ECurrentState::Patrol;

				if (TimeLapsed > TimeToTurn)
				{
					CurrentDirection *= -1;
					TimeLapsed = 0;
				}

				AddMovementInput(CurrentDirection, CurrentMovementSpeed, false);
			}
			break;

		case ECurrentState::Attack:
			//If Player character is out the current sighting range, the sentinel will move torwards it
			if (OwnPosition.Distance(OwnPosition, PlayerPosition) > CurrentSightingRange)
			{
				CurrentState = ECurrentState::Patrol;
				CurrentMovementSpeed = MaxMovementSpeed;
				
				SentinelComponent->Pursue(1, OwnPosition.X, SpawnLocation.X);
				SentinelComponent->Pursue(2, OwnPosition.Y, SpawnLocation.Y);
				SentinelComponent->Pursue(3, OwnPosition.Z, SpawnLocation.Z);

			}
			else if (OwnPosition.Distance(OwnPosition, PlayerPosition) <= CurrentSightingRange)
			{
				SentinelComponent->Pursue(1, OwnPosition.X, PlayerPosition.X);
				SentinelComponent->Pursue(2, OwnPosition.Y, PlayerPosition.Y);
				SentinelComponent->Pursue(3, OwnPosition.Z, PlayerPosition.Z);
			}
			break;

		break;
	}

}

void AEnemy::MentoramaTakeDamage(float Damage) {
	CurrentHealth -= Damage;

	/*if (CurrentHealth <= 0.0f)
		CurrentState = EState::Dead;*/
}