// Fill out your copyright notice in the Description page of Project Settings.


#include "SentinelComponent.h"
#include "Enemy.h"
#include "GameFramework/Pawn.h"

// Sets default values for this component's properties
USentinelComponent::USentinelComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}

void USentinelComponent::Pursue(int Index, float OwnAxisCoordinate, float PlayerAxisCoordinate)
{
	auto* Self = Cast<AEnemy>(GetOwner());


	switch (Index)
	{
	case 1:
		Self->CurrentDirection.Set(1, 0, 0);
		break;
	case 2:
		Self->CurrentDirection.Set(0, 1, 0);
		break;
	case 3:
		Self->CurrentDirection.Set(0, 0, 1);
		break;

		break;
	}
	
	if (PlayerAxisCoordinate >= .0f)
	{
		if (OwnAxisCoordinate < (PlayerAxisCoordinate - Self->CurrentSightingRange / 3))
		{
			Self->AddMovementInput(Self->CurrentDirection, Self->CurrentMovementSpeed, false);
		}
		else if (OwnAxisCoordinate > (PlayerAxisCoordinate + Self->CurrentSightingRange / 3))
		{
			Self->AddMovementInput(Self->CurrentDirection * -1, Self->CurrentMovementSpeed, false);
		}
	}
	else if (PlayerAxisCoordinate < .0f)
	{
		if (OwnAxisCoordinate < (PlayerAxisCoordinate - Self->CurrentSightingRange / 3))
		{
			Self->AddMovementInput(Self->CurrentDirection, Self->CurrentMovementSpeed, false);
		}
		else if (OwnAxisCoordinate > (PlayerAxisCoordinate + Self->CurrentSightingRange / 3))
		{
			Self->AddMovementInput(Self->CurrentDirection * -1, Self->CurrentMovementSpeed, false);
		}
	}
}

// Called when the game starts
void USentinelComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


// Called every frame
void USentinelComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

