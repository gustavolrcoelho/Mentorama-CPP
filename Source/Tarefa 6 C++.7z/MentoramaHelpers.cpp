// Fill out your copyright notice in the Description page of Project Settings.


#include "MentoramaHelpers.h"
#include "Kismet/KismetSystemLibrary.h"

int UMentoramaHelpers::Factorial(int Number)
{
	unsigned long int factorial = 1;

	if (Number == 0 || Number == 1)
		return 1;
	else
		while (Number > 1) {
			factorial *= Number;
			Number--;
		}
	return factorial;
}

int UMentoramaHelpers::FindFirstDivisibleNumber(int Number)
{
	int Result = 2;

	//Trava a UE
	/*do {
		if (Number % Result == 0)
			return Result;
		
		Result += 2;
	} while (true);*/


	do {
		if (Result % 2 == 0) {
			Result++;
			continue;
		}

		if (Number % Result == 0)
			break;
		else
			Result++;
	} while (Result < Number);

	return Result;
}

bool UMentoramaHelpers::IsPrime(int Number)
{
	bool Ans = true;

	if (Number <= 0)
		Ans = false;
	else if (Number == 1 || Number == 2)
		Ans = true;
	else
		for (int Divisor = 2; Divisor <= Number / 2; Divisor++)
			if (Number % Divisor == 0)
				Ans = false;
	return Ans;
}

int UMentoramaHelpers::IsBestScore(TArray<int> Scores)
{
	int Best = INT_MIN; //INT_MIN = Smallest value possible for an integer, -2147483647

	for (int i = 0; i < Scores.Num(); i++) {
		if (Scores[i] > Best) {
			Best = Scores[i];
		}
	}
	return Best;
}

void UMentoramaHelpers::PrintStringArray(TArray<FString> Array)
{
	for (int i = 0; i < Array.Num(); i++) {
		/*FString Temp = Array[i];
		UKismetSystemLibrary::PrintString(Temp);*/
		UE_LOG(LogTemp, Display, TEXT("%s"), *Array[i]);
	}
}

bool UMentoramaHelpers::IsPalindrome(FString Word)
{
	//TArray<bool> Answer;
	bool IsPalindrome = false;

	for (int i = 0, j = Word.Len() - 1; i <= Word.Len() / 2; i++, j--) {
		//Checks whether the letter at start+1 is the same as end-1, untill it reaches the middle of the word.
		//If they all check, it is a palindrome
		//Also checks if the previous test was also true, to prevent false positives
		//Like this case
		// P A R A N G A R I C O T I R I M I R R U A R O
		// O R A U R R I M I R I T O C I R A G N A R A P
		if (Word[i] == Word[j] && Word[i-1] == Word[j+1]) {
			//Answer.Add(true);
			IsPalindrome = true;
		}
		else {
			//Answer.Add(false);
			IsPalindrome = false;
		}
	}

	//Tentei fazer assim e n�o rolou
	//for (bool Result : Answer) {
	//	if (true) {
	//		IsPalindrome = true;
	//	}
	//	else if (false)
	//		IsPalindrome = false;
	//}

	return IsPalindrome;
}

void UMentoramaHelpers::ShuffleString(FString& Word)
{
	FString Helper = Word;
	TArray<int> Position;
	int Index = 0;
	
	//Starts an array with all the valid positions
	for (int i = 0; i < Word.Len(); i++) {
		Position.Add(i);
	}

	//Iterates through the lenght of the word
	for (int j = 0; j < Word.Len(); j++) {
		//If the number of valid positions is greater than 0, sorts a number 
		if (Position.Num() > 0) {
			Index = FMath::RandRange(0, Word.Len() - 1);

			//If the position array contains that position still, insert the letter into that position and removes the position from the array
			if (Position.Contains(Index)) {
				Word[Index] = Helper[j];
				Position.Remove(Index);
			}
			else {
				//If the position is no longer available, decreases iterator to stay in the same letter and tries again with a new position
				j--;
			}
		}
	}
}

int UMentoramaHelpers::SumAll(TArray<int> Array) {
	int Sum = 0;

	for (int i = 0; i < Array.Num(); i++)
		Sum += Array[i];

	return Sum;
}

bool UMentoramaHelpers::IsOdd(int Number) {
	if (Number % 2 == 0)
		return true;
	else
		return false;
}

