// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Enemy.generated.h"

UENUM(BlueprintType)
enum EState {
	Patrol,
	Idle,
	Attacking,
	FullHealth,
	Recovering,
	Dead
};

USTRUCT(BlueprintType)
struct FEnemyData {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float Health;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float Speed;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector Position;
};

UCLASS()
class MENTORAMA_API AEnemy : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AEnemy();
	//TArray<int>Vec[50];

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float Speed;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float TimeLapsed;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float TimeToTurn;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector Direction;
	
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float Health;

	EState State;

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	void MentoramaMoveEnemy(float DeltaTime);

	UFUNCTION(BlueprintCallable)
	void MentoramaTakeDamage(float Damage);
};
