// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy.h"
#include "MentoramaHelpers.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/KismetStringLibrary.h"

// Sets default values
AEnemy::AEnemy()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	Direction.Set(0, 1, 0);
	TimeLapsed = 0;
	TimeToTurn = 4;
	Speed = 1.0f;
	Health = 100;
	State = EState::Patrol;

	//for(int i = 0; i < 50; i++)
	//	Vec[i] = 0;
}

// Called when the game starts or when spawned
void AEnemy::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void AEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	FString Word1 = "Parangaricotirimirruaro";
	FString Word2 = "abcddcba";
	FString Word3 = "Joana";

	//UKismetSystemLibrary::PrintString(this, TEXT("&d"), UMentoramaHelpers::SumAll(Vec));
	//UKismetSystemLibrary::PrintString(this, UKismetStringLibrary::Conv_BoolToString((UMentoramaHelpers::IsPrime(10))));
	//UKismetSystemLibrary::PrintString(this, UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsOdd(TimeLapsed)));
	//UKismetSystemLibrary::PrintString(this, Word1 + TEXT(" palindrome result is ") + UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsPalindrome(Word1)));
	//UKismetSystemLibrary::PrintString(this, Word2 + TEXT(" palindrome result is ") + UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsPalindrome(Word2)));
	//UKismetSystemLibrary::PrintString(this, Word3 + TEXT(" palindrome result is ") + UKismetStringLibrary::Conv_BoolToString(UMentoramaHelpers::IsPalindrome(Word3)));
	
	UKismetSystemLibrary::PrintString(this, TEXT("Before shuffling:  ") + Word1);
	UMentoramaHelpers::ShuffleString(Word1);
	UKismetSystemLibrary::PrintString(this, TEXT("After shuffling:  ") + Word1);

	switch (State) {
		case EState::Idle:
			if (EState::Recovering) { //If enemy is idle,
				if (Health == 100.0f) { //check it's HP
					State = EState::FullHealth; //and if not full
				}
				else {
					Health += 5 * DeltaTime; //start recovering.
				}
		case EState::FullHealth: //If enemy is at full HP
			State = EState::Patrol; //start patrolling again
			break;
		case EState::Dead: //If enemy is dead
			Destroy(); //despawn corpse to free resources.
			break;
		case EState::Patrol: //If patrolling
			if (Health < 100.0f) { //and HP is not full
				State = EState::Idle; //stop.
			}
			else {
				MentoramaMoveEnemy(DeltaTime); //If full, keep walking
			}
			break;
		case EState::Attacking:
			// TO DO
			break;
			}
	}
}

// Called to bind functionality to input
void AEnemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AEnemy::MentoramaMoveEnemy(float DeltaTime){
	TimeLapsed += DeltaTime;

	if (TimeLapsed > TimeToTurn) {
		Direction *= -1;
		TimeLapsed = 0;
	}

	AddMovementInput(Direction, Speed, false);
}

void AEnemy::MentoramaTakeDamage(float Damage){
	Health -= Damage;

	if (Health <= 0.0f)
		Destroy();
}